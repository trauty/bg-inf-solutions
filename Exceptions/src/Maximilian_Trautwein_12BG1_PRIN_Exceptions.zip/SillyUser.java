public class SillyUser extends Exception
{
    public SillyUser(String errorMsg)
    {
        super(errorMsg);
    }
}
