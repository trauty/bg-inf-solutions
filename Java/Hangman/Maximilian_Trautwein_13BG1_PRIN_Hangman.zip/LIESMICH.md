# Echtzeitmehrspieler-Hangman
Implementation mit Threads und Nebenläufigkeit