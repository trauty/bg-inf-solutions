public class Biene extends Fliegen
{

    @Override
    public void fliegen()
    {
        System.out.println("Summsumm");
    }
}
