public class Fledermaus extends Fliegen
{
    @Override
    public void fliegen()
    {
        System.out.println("Flatterflatter");
    }
}
