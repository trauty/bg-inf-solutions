public abstract class Fliegen
{
    abstract void fliegen();
}
