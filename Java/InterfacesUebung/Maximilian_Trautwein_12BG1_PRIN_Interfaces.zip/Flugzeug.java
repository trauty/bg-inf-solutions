public class Flugzeug extends Fliegen
{
    @Override
    void fliegen()
    {
        System.out.println("***ABFLUG VOM FLUGHAFEN FRANKFURT***");
    }
}
