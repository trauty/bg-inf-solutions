public class Kunde
{

}
