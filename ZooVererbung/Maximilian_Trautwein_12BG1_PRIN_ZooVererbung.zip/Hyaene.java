
public class Hyaene extends Fleischfresser {
  public Hyaene(String name, double gewicht, boolean lebendig, Zoo zoo) {
        super(name, gewicht, lebendig, false, zoo);
  }

}
